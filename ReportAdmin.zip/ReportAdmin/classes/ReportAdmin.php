<?php

class ReportAdmin extends OssnObject {
   
    public function getAds() {
        	$this->statement("SELECT * FROM ossn_likes WHERE (
	                     type='report:post');");
				$this->execute();
				return $this->fetch(true);

    }
    

}
