<?php

define('__ReportAdmin__', ossn_route()->com . 'ReportAdmin/');
require_once(__ReportAdmin__ . 'classes/ReportAdmin.php');

function ra_init() {
		ossn_register_com_panel('ReportAdmin', 'settings');
		
}

ossn_register_callback('ossn', 'init', 'ra_init');