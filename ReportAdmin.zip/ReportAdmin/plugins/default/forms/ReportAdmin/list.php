<?php

$ra = new ReportAdmin;
$pagination = new OssnPagination;
$pagination->setItem($ra->getAds());
?>

<div class="row">
<table class="table">
    <tbody>
    <tr class="table-titles">
        <td><?php echo ossn_print('Id do post'); ?></td>
        <td><?php echo ossn_print('Link do post'); ?></td>
    </tr>
    <?php
    $items = $pagination->getItem();
    if ($items) {
        foreach ($items as $ra) {
            ?>
            <tr>
                <td><?php echo $ra->subject_id; ?></td>
                <td><a target="_blank" href="/post/view/<?php echo $ra->subject_id; ?>">Abrir post</td>


            </tr>
        <?php
        }

    }?>
    </tbody>
</table>
</div>
<div class="row">
	<?php echo $pagination->pagination(); ?>
</div>