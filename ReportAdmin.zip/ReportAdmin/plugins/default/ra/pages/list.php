<?php

echo ossn_view_form('list', array(
        'action' => ossn_site_url() . 'action/ra/delete',
        'component' => 'ReportAdmin',
    ), false);
