<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */

define('__REPORT__', ossn_route()->com . 'Report/');
require_once(__REPORT__ . 'classes/Report.php');
/**
 * Report component initlize
 *
 * return void
 */
function report_config2(){
		ossn_register_action('post/report', __REPORT__. 'actions/post/report.php');
        ossn_register_action('post/unreport', __REPORT__ . 'actions/post/unreport.php');
		
		ossn_register_callback('wall', 'load:item', 'ossn_wall_report_menu');
		ossn_register_callback('entity', 'load:comment:share:like', 'ossn_entity_report_link');
		ossn_register_callback('post', 'delete', 'ossn_post_report_delete');
		ossn_register_callback('delete', 'entity', 'ossn_entity_report_delete');
		
		ossn_extend_view('js/opensource.socialnetwork', 'js/report');
		ossn_extend_view('css/ossn.default', 'css/reports');
		
		ossn_extend_view('likes/post/likes', 'report/post/reports');
		ossn_extend_view('likes/post/likes_entity', 'report/post/reports_entity');
		
		ossn_register_page('reports', 'ossn_reportsview_page_handler');	
}
/**
 * Register a post menu item
 * 
 * return void
 */
function ossn_wall_report_menu($callback, $type, $params){
	$guid = $params['post']->guid;
	
	ossn_unregister_menu('report', 'postextra'); 
	ossn_unregister_menu('unreport', 'postextra'); 
	
	if(!empty($guid)){
		$report = new Report;
		if(!$report->isReportd($guid, ossn_loggedin_user()->guid)){
			ossn_register_menu_item('postextra', array(
					'name' => 'report', 
					'href' => "javascript:;",
					'id' => 'ossn-report-'.$guid,
					'data-guid' => $guid,
					'data-type' => 'post',
					'text' => ossn_print('ossn:report'),
			));
		} else {
			ossn_register_menu_item('postextra', array(
					'name' => 'unreport', 
					'href' => "javascript:;",
					'id' => 'ossn-report-'.$guid,
					'data-guid' => $guid,		
					'data-type' => 'post',
					'text' => ossn_print('ossn:unreport'),
			));			
		}
	}
}
/**
 * Add a entity report menu item
 *
 * @return void
 */
function ossn_entity_report_link($callback, $type, $params){
	$guid = $params['entity']->guid;
	
	ossn_unregister_menu('report', 'entityextra'); 
	
	if(!empty($guid)){
		$reports = new Report;
		if(!$reports->isReportd($guid, ossn_loggedin_user()->guid, 'entity')){
			ossn_register_menu_item('entityextra', array(
					'name' => 'report', 
					'href' => "javascript:;",
					'id' => 'ossn-report-'.$guid,
					'data-type' => 'entity',
					'data-guid' => $guid,	
					'text' => ossn_print('ossn:report'),
			));
		} else {
			ossn_register_menu_item('entityextra', array(
					'name' => 'unreport', 
					'href' => "javascript:;",
					'id' => 'ossn-report-'.$guid,					
					'data-type' => 'entity',
					'data-guid' => $guid,	
					'text' => ossn_print('ossn:unreport'),
			));			
		}
	}
}
/**
 * View post reports modal box
 *
 * @return string;
 */
function ossn_reportsview_page_handler() {
    echo ossn_plugin_view('output/ossnbox', array(
        'title' => ossn_print('people:report:this'),
        'contents' => ossn_plugin_view('report/pages/view'),
        'control' => false,
    ));
}
/**
 * Delete post reports
 *
 * @return void
 */
function ossn_post_report_delete($name, $type, $params) {
    $delete = new Report;
    $delete->deleteReports($params);
}
/**
 * Delete entity reports
 *
 * @return void
 */
function ossn_entity_report_delete($name, $type, $params){
    $delete = new Report;
    $delete->deleteReports($params['entity'], 'entity');	
}

ossn_register_callback('ossn', 'init', 'report_config2');
