
Ossn.RegisterStartupFunction(function() {
    $(document).ready(function() {


$("post-control-report").replaceWith( "Denunciado" );

$('body').on('click','.ossn-wall-post', function(){ 
 setTimeout(function(){ 

   $('.post-control-dislike').parent().nextAll('li').hide();  }, 1000);
    });
$('body').find('.post-control-dislike').parent().nextAll('li').hide();

$('body').on('click','.post-control-dislike', function(){                         $(this).parent().nextAll('li').show()      });
$('body').on('click','.post-control-undislike', function(){    $('.post-control-undislike, .post-control-report').css("background","#fff");                          $(this).parent().nextAll('li').hide() });

$('.post-control-undislike, .post-control-report,post-control-hidepost').css("background","#ffffee");

        $('body').delegate('.post-control-report, .entity-menu-extra-report', 'click', function() {
            var $guid = $(this).attr('data-guid');
            var $type = $(this).attr('data-type');
            if($type == 'post'){
                var $params = '&post=' + $guid;
            }
            if($type == 'entity'){
                var $params = '&entity=' + $guid;           
            }
            if ($guid) {
                Ossn.PostRequest({
                    url: Ossn.site_url + 'action/post/report',
                    beforeSend: function() {
                        $('#ossn-report-' + $guid).html('<img src="' + Ossn.site_url + 'components/OssnComments/images/loading.gif" />');
                    },
                    params: $params,
                    callback: function(callback) {
                        if (callback['done'] !== 0) {
                            $('#ossn-report-' + $guid).html(Ossn.Print('ossn:unreport'));
                            $('#ossn-report-' + $guid).removeClass('post-control-report');
                            $('#ossn-report-' + $guid).addClass('post-control-unreport');
         $('#activity-item-' + $guid).hide();
                            Ossn.trigger_message('Analizaremos o conteúdo deste post, por enquanto retiramos para a visualização.', 'info');
                        } else {
                            $('#ossn-report-' + $guid).html(Ossn.Print('ossn:report'));
                        }
                    },
                });
            }
        });
        $('body').delegate('.post-control-unreport, .entity-menu-extra-unreport', 'click', function() {
            var $guid = $(this).attr('data-guid');
            var $type = $(this).attr('data-type');    
            if($type == 'post'){
                var $params = '&post=' + $guid;
            }
            if($type == 'entity'){
                var $params = '&entity=' + $guid;           
            }                 
            if ($guid) {
                Ossn.PostRequest({
                    url: Ossn.site_url + 'action/post/unreport',
                    beforeSend: function() {
                        $('#ossn-report-' + $guid).html('<img src="' + Ossn.site_url + 'components/OssnComments/images/loading.gif" />');
                    },
                    params: $params,
                    callback: function(callback) {
                        if (callback['done'] !== 0) {
                            $('#ossn-report-' + $guid).html(Ossn.Print('ossn:report'));
                            $('#ossn-report-' + $guid).addClass('post-control-report');
                            $('#ossn-report-' + $guid).removeClass('post-control-unreport');
                        } else {
                            $('#ossn-report-' + $guid).html(Ossn.Print('ossn:unreport'));
                        }
                    },
                });
            }
        });        
    });
});
Ossn.ViewReports = function($post, $type) {
    if (!$type) {
        $type = 'post';
    }
    Ossn.MessageBox('reports/view?guid=' + $post + '&type=' + $type);
};