.report-share {
    margin-top: 0px;
    border-top: 0px;
}