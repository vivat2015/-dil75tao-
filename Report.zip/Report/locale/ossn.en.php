<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
$en = array(
			'people:report:this' => 'As pessoas que não denunciaram desta postagem',
			'ossn:report' => 'Denunciar',
			'ossn:unreport' => 'Desbloquear',
			
	'ossn:report:this' => '%s não denunciaram',
	'ossn:report:you:and:this' => 'Você e %s denunciou',
	'ossn:report:people' => '%s Pessoas',
	'ossn:report:person' => '%s Pessoa',
	'ossn:reportd:you' => 'Você denunciou',
			);
ossn_register_languages('en', $en); 