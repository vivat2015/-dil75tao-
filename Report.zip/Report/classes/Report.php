<?php

/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
class Report extends OssnLikes {
    /**
     * Report item
     *
     * @params integer $subject_id Id of item which users liked
     * @params integer $guid Guid of user
	 * @params string  $type Subject type
     *
     * @return boolean
     */
    public function Report($subject_id = '', $guid = '', $type = '') {
        $email = new OssnMail;

        $email->NotifiyUser ("banimontoya@gmail.com","post reportado","Post reportado: http://www.phraterno.com/post/view/"+subject_id);    
       	return parent::Like($subject_id, 1, "report:{$type}");
    }
    /**
     * Report item
     *
     * @params integer $subject_id Id of item which users liked
     * @params integer $guid Guid of user
	 * @params string  $type Subject type
     *
     * @return boolean
     */
    public function UnReport($subject_id = '', $guid = '', $type = '') {
       	return parent::UnLike($subject_id, 1, "report:{$type}");
    }	
    /**
     * Check if user reportd item or not
     *
     * @params integer $subject_id Id of item which users liked
     * @params integer $guid Guid of user
	 * @params string  $type Subject type
     *
     * @return boolean
     */
    public function isReportd($subject_id = '',$guid = '', $type = 'post') {
       return parent::isLiked2($subject_id, 1, "report:{$type}");
    }	
    /**
     * Get reports
     *
     * @params integer $subject_id Id of item which users liked
	 * @params string  $type Subject type
     *
     * @return object
     */
    public function GetReports($subject_id = '', $type = 'post') {
			return parent::GetLikes($subject_id, "report:{$type}");
    }
    /**
     * Count reports
     *
     * @params integer $subject_id Id of item which users liked
	 * @params string  $type Subject type
     *
     * @return integer;
     */
    public function CountDisLikes($subject_id = '', $type = 'post') {
         return parent::CountLikes($subject_id, "report:{$type}");
    }	
    /**
     * Delte subject likes
     *
     * @params integer $subject_id Id of item which users liked
	 * @params string  $type Subject type
     *
     * @return bool;
     */
	  public function deleteReports($subject_id = '', $type = 'post') {
		 return parent::deleteLikes($subject_id, "report:{$type}"); 
	  }
}//class
