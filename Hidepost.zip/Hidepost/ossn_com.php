<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */

define('__HIDEPOST__', ossn_route()->com . 'Hidepost/');
require_once(__HIDEPOST__ . 'classes/Hidepost.php');
/**
 * Hidepost component initlize
 *
 * return void
 */
function hidepost_init(){
		ossn_register_action('post/hidepost', __HIDEPOST__. 'actions/post/hidepost.php');
        ossn_register_action('post/unhidepost', __HIDEPOST__ . 'actions/post/unhidepost.php');
		
		ossn_register_callback('wall', 'load:item', 'ossn_wall_hidepost_menu');
		ossn_register_callback('entity', 'load:comment:share:like', 'ossn_entity_hidepost_link');
		ossn_register_callback('post', 'delete', 'ossn_post_hidepost_delete');
		ossn_register_callback('delete', 'entity', 'ossn_entity_hidepost_delete');
		
		ossn_extend_view('js/opensource.socialnetwork', 'js/hidepost');
		ossn_extend_view('css/ossn.default', 'css/hideposts');
		
		ossn_extend_view('likes/post/likes', 'hidepost/post/hideposts');
		ossn_extend_view('likes/post/likes_entity', 'hidepost/post/hideposts_entity');
		
		ossn_register_page('hideposts', 'ossn_hidepostsview_page_handler');	
}
/**
 * Register a post menu item
 * 
 * return void
 */
function ossn_wall_hidepost_menu($callback, $type, $params){
	$guid = $params['post']->guid;
	
	ossn_unregister_menu('hidepost', 'postextra'); 
	ossn_unregister_menu('unhidepost', 'postextra'); 
	
	if(!empty($guid)){
		$hidepost = new Hidepost;
		if(!$hidepost->isHidepostd($guid, ossn_loggedin_user()->guid)){
			ossn_register_menu_item('postextra', array(
					'name' => 'hidepost', 
					'href' => "javascript:;",
					'id' => 'ossn-hidepost-'.$guid,
					'data-guid' => $guid,
					'data-type' => 'post',
					'text' => ossn_print('ossn:hidepost'),
			));
		} else {
			ossn_register_menu_item('postextra', array(
					'name' => 'unhidepost', 
					'href' => "javascript:;",
					'id' => 'ossn-hidepost-'.$guid,
					'data-guid' => $guid,		
					'data-type' => 'post',
					'text' => ossn_print('ossn:unhidepost'),
			));			
		}
	}
}
/**
 * Add a entity hidepost menu item
 *
 * @return void
 */
function ossn_entity_hidepost_link($callback, $type, $params){
	$guid = $params['entity']->guid;
	
	ossn_unregister_menu('hidepost', 'entityextra'); 
	
	if(!empty($guid)){
		$hideposts = new Hidepost;
		if(!$hideposts->isHidepostd($guid, ossn_loggedin_user()->guid, 'entity')){
			ossn_register_menu_item('entityextra', array(
					'name' => 'hidepost', 
					'href' => "javascript:;",
					'id' => 'ossn-hidepost-'.$guid,
					'data-type' => 'entity',
					'data-guid' => $guid,	
					'text' => ossn_print('ossn:hidepost'),
			));
		} else {
			ossn_register_menu_item('entityextra', array(
					'name' => 'unhidepost', 
					'href' => "javascript:;",
					'id' => 'ossn-hidepost-'.$guid,					
					'data-type' => 'entity',
					'data-guid' => $guid,	
					'text' => ossn_print('ossn:unhidepost'),
			));			
		}
	}
}
/**
 * View post hideposts modal box
 *
 * @return string;
 */
function ossn_hidepostsview_page_handler() {
    echo ossn_plugin_view('output/ossnbox', array(
        'title' => ossn_print('people:hidepost:this'),
        'contents' => ossn_plugin_view('hidepost/pages/view'),
        'control' => false,
    ));
}
/**
 * Delete post hideposts
 *
 * @return void
 */
function ossn_post_hidepost_delete($name, $type, $params) {
    $delete = new Hidepost;
    $delete->deleteHideposts($params);
}
/**
 * Delete entity hideposts
 *
 * @return void
 */
function ossn_entity_hidepost_delete($name, $type, $params){
    $delete = new Hidepost;
    $delete->deleteHideposts($params['entity'], 'entity');	
}

ossn_register_callback('ossn', 'init', 'hidepost_init');
