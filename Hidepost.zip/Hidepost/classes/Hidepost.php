<?php

/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
class Hidepost extends OssnLikes {
    /**
     * Hidepost item
     *
     * @params integer $subject_id Id of item which users liked
     * @params integer $guid Guid of user
	 * @params string  $type Subject type
     *
     * @return boolean
     */
    public function Hidepost($subject_id = '', $guid = '', $type = '') {
       	return parent::Like($subject_id, $guid, "hidepost:{$type}");
    }
    /**
     * Hidepost item
     *
     * @params integer $subject_id Id of item which users liked
     * @params integer $guid Guid of user
	 * @params string  $type Subject type
     *
     * @return boolean
     */
    public function UnHidepost($subject_id = '', $guid = '', $type = '') {
       	return parent::UnLike($subject_id, $guid, "hidepost:{$type}");
    }	
    /**
     * Check if user hidepostd item or not
     *
     * @params integer $subject_id Id of item which users liked
     * @params integer $guid Guid of user
	 * @params string  $type Subject type
     *
     * @return boolean
     */
    public function isHidepostd($subject_id = '', $guid = '', $type = 'post') {
       return parent::isLiked($subject_id, ossn_loggedin_user()->guid, "hidepost:{$type}");
    }	
    /**
     * Get hideposts
     *
     * @params integer $subject_id Id of item which users liked
	 * @params string  $type Subject type
     *
     * @return object
     */
    public function GetHideposts($subject_id = '', $type = 'post') {
			return parent::GetLikes($subject_id, "hidepost:{$type}");
    }
    /**
     * Count hideposts
     *
     * @params integer $subject_id Id of item which users liked
	 * @params string  $type Subject type
     *
     * @return integer;
     */
    public function CountHidePosts($subject_id = '', $type = 'post') {
         return parent::CountLikes($subject_id, "hidepost:{$type}");
    }	
    /**
     * Delte subject likes
     *
     * @params integer $subject_id Id of item which users liked
	 * @params string  $type Subject type
     *
     * @return bool;
     */
	  public function deleteHideposts($subject_id = '', $type = 'post') {
		 return parent::deleteLikes($subject_id, "hidepost:{$type}"); 
	  }
}//class
