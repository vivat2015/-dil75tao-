<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
$en = array(
			'people:hidepost:this' => 'People who hidepostd this post',
			'ossn:hidepost' => '',
			'ossn:unhidepost' => 'Unhide post',
			
	'ossn:hidepost:this' => '%s hidepostd this',
	'ossn:hidepost:you:and:this' => 'You and %s hidepostd this',
	'ossn:hidepost:people' => '%s People',
	'ossn:hidepost:person' => '%s Person',
	'ossn:hidepostd:you' => 'You hidepostd this',
			);
ossn_register_languages('en', $en); 