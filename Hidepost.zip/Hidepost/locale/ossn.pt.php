<?php
/**
 * Open Source Social Network
 *
 * @packageOpen Source Social Network
 * @author    Open Social Website Core Team <info@informatikon.com>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */
$pt = array(
			'people:hidepost:this' => 'As pessoas que não gostaram desta postagem',
			'ossn:hidepost' => 'Ocultar post',
			'ossn:unhidepost' => 'Voltar a mostra-lo',
			
	'ossn:hidepost:this' => '%s não querem ver',
	'ossn:hidepost:you:and:this' => 'Você e %s não querem ver',
	'ossn:hidepost:people' => '%s Pessoas',
	'ossn:hidepost:person' => '%s Pessoa',
	'ossn:hidepostd:you' => 'Você não gostou',
			);
ossn_register_languages('pt', $pt); 