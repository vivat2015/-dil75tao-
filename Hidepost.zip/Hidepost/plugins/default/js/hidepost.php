Ossn.RegisterStartupFunction(function() {
    $(document).ready(function() {
        $('body').delegate('.post-control-hidepost, .entity-menu-extra-hidepost', 'click', function() {
            var $guid = $(this).attr('data-guid');
            var $type = $(this).attr('data-type');
            if($type == 'post'){
	            var $params = '&post=' + $guid;
            }
            if($type == 'entity'){
 	            var $params = '&entity=' + $guid;           
            }
            if ($guid) {
                Ossn.PostRequest({
                    url: Ossn.site_url + 'action/post/hidepost',
                    beforeSend: function() {
                        $('#ossn-hidepost-' + $guid).html('<img src="' + Ossn.site_url + 'components/OssnComments/images/loading.gif" />');
                    },
                    params: $params,
                    callback: function(callback) {
                        if (callback['done'] !== 0) {
                            $('#ossn-hidepost-' + $guid).html(Ossn.Print('ossn:unhidepost'));
                            $('#ossn-hidepost-' + $guid).removeClass('post-control-hidepost');
                            $('#ossn-hidepost-' + $guid).addClass('post-control-unhidepost');
                               $('#activity-item-' + $guid).hide();
                            Ossn.trigger_message('Você não verá mais este post.', 'info');
                      
                        } else {
                            $('#ossn-hidepost-' + $guid).html(Ossn.Print('ossn:hidepost'));
                        }
                    },
                });
            }
        });
		$('body').delegate('.post-control-unhidepost, .entity-menu-extra-unhidepost', 'click', function() {
            var $guid = $(this).attr('data-guid');
            var $type = $(this).attr('data-type');    
            if($type == 'post'){
	            var $params = '&post=' + $guid;
            }
            if($type == 'entity'){
 	            var $params = '&entity=' + $guid;           
            }                 
            if ($guid) {
                Ossn.PostRequest({
                    url: Ossn.site_url + 'action/post/unhidepost',
                    beforeSend: function() {
                        $('#ossn-hidepost-' + $guid).html('<img src="' + Ossn.site_url + 'components/OssnComments/images/loading.gif" />');
                    },
                    params: $params,
                    callback: function(callback) {
                        if (callback['done'] !== 0) {
                            $('#ossn-hidepost-' + $guid).html(Ossn.Print('ossn:hidepost'));
                            $('#ossn-hidepost-' + $guid).addClass('post-control-hidepost');
                            $('#ossn-hidepost-' + $guid).removeClass('post-control-unhidepost');
                        } else {
                            $('#ossn-hidepost-' + $guid).html(Ossn.Print('ossn:unhidepost'));
                        }
                    },
                });
            }
        });        
    });
});
Ossn.ViewHidePosts = function($post, $type) {
    if (!$type) {
        $type = 'post';
    }
    Ossn.MessageBox('hideposts/view?guid=' + $post + '&type=' + $type);
};