.ossn-likes-view a.right.btn.btn-danger{
	font-size: 12px;
  	margin-top: 8px;
	margin-right: 5px;
    	padding: 3px 5px 3px 5px;
    	border-radius: 1px;
    	display: none;
}
.ossn-likes-view a.right.btn.btn-primary{
	font-size: 12px;
	margin-top: 8px;
	margin-right: 5px;
    	padding: 3px 5px 3px 5px;
    	border-radius: 1px;
    	display: none;
}
